# OsTeO — deploy con Stripe

## 1. Crear el repo en GitHub
1. Ve a github.com → New repository.
2. Nombre: `osteo-site` (o el que prefieras). Déjalo **vacío** — sin README, sin .gitignore, sin licencia (ya vienen en este zip).
3. Crea el repo y copia la URL que te da (algo como `https://github.com/tu-usuario/osteo-site.git`).

## 2. Subir este código
Extrae este zip en una carpeta y desde ahí corre, en orden:

```
git init
git add .
git commit -m "Initial site with Stripe checkout"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/osteo-site.git
git push -u origin main
```

## 3. Conectar el repo a Netlify
1. En Netlify: Add new site → Import an existing project → GitHub.
2. Autoriza y elige el repo `osteo-site`.
3. Build settings: déjalos vacíos (publish directory = `.`, sin build command). El archivo `netlify.toml` ya trae la configuración de la función.
4. Deploy site.

## 4. Configurar la clave de Stripe
1. En tu Dashboard de Stripe (modo test): Developers → API keys → copia la clave secreta (`sk_test_...`).
2. En Netlify: Site settings → Environment variables → Add a variable.
   - Key: `STRIPE_SECRET_KEY`
   - Value: tu `sk_test_...`
3. Vuelve a desplegar el sitio (Deploys → Trigger deploy) para que la función tome la variable nueva.

## 5. Probar
Agrega algo al carrito, dale Checkout. Te debe mandar a una página real de Stripe.
Usa una tarjeta de prueba: `4242 4242 4242 4242`, cualquier fecha futura, cualquier CVC.
Si el pago sale bien, Stripe te regresa al sitio y el carrito se vacía solo.

## Qué NO hacer
- No subas tu clave secreta (`sk_...`) al repo ni la pegues en el chat. Solo vive en la variable de entorno de Netlify.
- No uses la clave `sk_live_...` hasta que quieras cobrar de verdad.

## Después, cuando quieras cobrar de verdad
Repite el paso 4 pero con las claves que empiezan con `sk_live_` y `pk_live_` desde el modo Live de Stripe, en un nuevo environment variable o reemplazando el actual.
